// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 7/18/2005 5:13:49 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 

package org.jfree.chart.demo;

import java.io.*;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.MeterPlot;
import org.jfree.data.general.DefaultValueDataset;

public class MeterChartDemo1
{

    public MeterChartDemo1()
    {
    }

    public static void main(String args[])
    {
        DefaultValueDataset defaultvaluedataset = new DefaultValueDataset(75D);
        MeterPlot meterplot = new MeterPlot(defaultvaluedataset);
        JFreeChart jfreechart = new JFreeChart("Scaled Image Test", meterplot);
        try
        {
            File file = new File("meterchart100.png");
            BufferedOutputStream bufferedoutputstream = new BufferedOutputStream(new FileOutputStream(file));
            java.awt.image.BufferedImage bufferedimage = jfreechart.createBufferedImage(200, 200, 400D, 400D, null);
            ChartUtilities.writeBufferedImageAsPNG(bufferedoutputstream, bufferedimage);
        }
        catch(IOException ioexception)
        {
            System.out.println(ioexception.toString());
        }
    }
}