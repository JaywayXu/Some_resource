// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 7/18/2005 5:13:53 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 

package org.jfree.chart.demo;

import java.awt.*;
import javax.swing.JPanel;
import org.jfree.chart.*;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class PieChartDemo3 extends ApplicationFrame
{

    public PieChartDemo3(String s)
    {
        super(s);
        DefaultPieDataset defaultpiedataset = new DefaultPieDataset();
        JFreeChart jfreechart = createChart(defaultpiedataset);
        ChartPanel chartpanel = new ChartPanel(jfreechart);
        chartpanel.setPreferredSize(new Dimension(500, 270));
        setContentPane(chartpanel);
    }

    private static JFreeChart createChart(PieDataset piedataset)
    {
        JFreeChart jfreechart = ChartFactory.createPieChart("Pie Chart Demo 3", piedataset, true, true, false);
        PiePlot pieplot = (PiePlot)jfreechart.getPlot();
        pieplot.setNoDataMessage("No data available so we go into this really long spiel about what that means and it runs off the end of the line but what can you do about that!");
        pieplot.setNoDataMessageFont(new Font("Serif", 2, 10));
        pieplot.setNoDataMessagePaint(Color.red);
        return jfreechart;
    }

    public static JPanel createDemoPanel()
    {
        JFreeChart jfreechart = createChart(new DefaultPieDataset());
        return new ChartPanel(jfreechart);
    }

    public static void main(String args[])
    {
        PieChartDemo3 piechartdemo3 = new PieChartDemo3("Pie Chart Demo 3");
        piechartdemo3.pack();
        RefineryUtilities.centerFrameOnScreen(piechartdemo3);
        piechartdemo3.setVisible(true);
    }
}