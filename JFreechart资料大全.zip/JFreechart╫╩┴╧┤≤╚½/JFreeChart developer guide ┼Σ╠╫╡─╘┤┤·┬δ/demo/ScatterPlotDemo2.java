// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 7/18/2005 5:13:56 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 

package org.jfree.chart.demo;

import java.awt.Dimension;
import org.jfree.chart.*;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYDotRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

// Referenced classes of package demo:
//            SampleXYDataset2

public class ScatterPlotDemo2 extends ApplicationFrame
{

    public ScatterPlotDemo2(String s)
    {
        super(s);
        SampleXYDataset2 samplexydataset2 = new SampleXYDataset2();
        JFreeChart jfreechart = createChart(samplexydataset2);
        ChartPanel chartpanel = new ChartPanel(jfreechart);
        chartpanel.setPreferredSize(new Dimension(500, 270));
        chartpanel.setVerticalAxisTrace(true);
        chartpanel.setHorizontalAxisTrace(true);
        chartpanel.setDomainZoomable(true);
        chartpanel.setRangeZoomable(true);
        setContentPane(chartpanel);
    }

    private JFreeChart createChart(XYDataset xydataset)
    {
        JFreeChart jfreechart = ChartFactory.createScatterPlot("Scatter Plot Demo", "X", "Y", xydataset, PlotOrientation.HORIZONTAL, true, false, false);
        XYPlot xyplot = jfreechart.getXYPlot();
        xyplot.setRenderer(new XYDotRenderer());
        NumberAxis numberaxis = (NumberAxis)xyplot.getDomainAxis();
        numberaxis.setAutoRangeIncludesZero(false);
        return jfreechart;
    }

    public static void main(String args[])
    {
        ScatterPlotDemo2 scatterplotdemo2 = new ScatterPlotDemo2("Scatter Plot Demo 2");
        scatterplotdemo2.pack();
        RefineryUtilities.centerFrameOnScreen(scatterplotdemo2);
        scatterplotdemo2.setVisible(true);
    }
}