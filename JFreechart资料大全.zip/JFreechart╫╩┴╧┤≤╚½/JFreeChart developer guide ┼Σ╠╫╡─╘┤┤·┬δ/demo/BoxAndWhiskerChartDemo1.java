// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 7/18/2005 5:13:40 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 

package org.jfree.chart.demo;

import java.awt.Color;
import java.awt.Dimension;
import java.util.ArrayList;
import javax.swing.JPanel;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.BoxAndWhiskerRenderer;
import org.jfree.data.statistics.BoxAndWhiskerCategoryDataset;
import org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class BoxAndWhiskerChartDemo1 extends ApplicationFrame
{

    public BoxAndWhiskerChartDemo1(String s)
    {
        super(s);
        BoxAndWhiskerCategoryDataset boxandwhiskercategorydataset = createDataset();
        JFreeChart jfreechart = createChart(boxandwhiskercategorydataset);
        ChartPanel chartpanel = new ChartPanel(jfreechart, false);
        chartpanel.setPreferredSize(new Dimension(500, 270));
        setContentPane(chartpanel);
    }

    private static BoxAndWhiskerCategoryDataset createDataset()
    {
        DefaultBoxAndWhiskerCategoryDataset defaultboxandwhiskercategorydataset = new DefaultBoxAndWhiskerCategoryDataset();
        for(int i = 0; i < 3; i++)
        {
            for(int j = 0; j < 5; j++)
            {
                java.util.List list = createValueList(0.0D, 20D, 20);
                defaultboxandwhiskercategorydataset.add(list, "Series " + i, "Category " + j);
            }

        }

        return defaultboxandwhiskercategorydataset;
    }

    private static java.util.List createValueList(double d, double d1, int i)
    {
        ArrayList arraylist = new ArrayList();
        for(int j = 0; j < i; j++)
        {
            double d2 = d + Math.random() * (d1 - d);
            arraylist.add(new Double(d2));
        }

        return arraylist;
    }

    private static JFreeChart createChart(BoxAndWhiskerCategoryDataset boxandwhiskercategorydataset)
    {
        CategoryAxis categoryaxis = new CategoryAxis(null);
        NumberAxis numberaxis = new NumberAxis("Value");
        BoxAndWhiskerRenderer boxandwhiskerrenderer = new BoxAndWhiskerRenderer();
        CategoryPlot categoryplot = new CategoryPlot(boxandwhiskercategorydataset, categoryaxis, numberaxis, boxandwhiskerrenderer);
        JFreeChart jfreechart = new JFreeChart("Box-and-Whisker Chart Demo 1", categoryplot);
        jfreechart.setBackgroundPaint(Color.white);
        categoryplot.setBackgroundPaint(Color.lightGray);
        categoryplot.setDomainGridlinePaint(Color.white);
        categoryplot.setDomainGridlinesVisible(true);
        categoryplot.setRangeGridlinePaint(Color.white);
        numberaxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        return jfreechart;
    }

    public static JPanel createDemoPanel()
    {
        JFreeChart jfreechart = createChart(createDataset());
        return new ChartPanel(jfreechart);
    }

    public static void main(String args[])
    {
        BoxAndWhiskerChartDemo1 boxandwhiskerchartdemo1 = new BoxAndWhiskerChartDemo1("Box-and-Whisker Chart Demo 1");
        boxandwhiskerchartdemo1.pack();
        RefineryUtilities.centerFrameOnScreen(boxandwhiskerchartdemo1);
        boxandwhiskerchartdemo1.setVisible(true);
    }
}