// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 7/18/2005 5:14:03 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 

package org.jfree.chart.demo;

import java.awt.*;
import javax.swing.JPanel;
import org.jfree.chart.*;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.*;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

// Referenced classes of package demo:
//            SimpleIntervalXYDataset

public class XYBarChartDemo4 extends ApplicationFrame
{

    public XYBarChartDemo4(String s)
    {
        super(s);
        IntervalXYDataset intervalxydataset = createDataset();
        JFreeChart jfreechart = createChart(intervalxydataset);
        ChartPanel chartpanel = new ChartPanel(jfreechart);
        chartpanel.setPreferredSize(new Dimension(500, 300));
        setContentPane(chartpanel);
    }

    private static JFreeChart createChart(IntervalXYDataset intervalxydataset)
    {
        JFreeChart jfreechart = ChartFactory.createXYBarChart("XYBarChartDemo4", "X", false, "Y", intervalxydataset, PlotOrientation.VERTICAL, true, false, false);
        jfreechart.setBackgroundPaint(new GradientPaint(0.0F, 0.0F, Color.white, 1000F, 0.0F, Color.blue));
        XYPlot xyplot = (XYPlot)jfreechart.getPlot();
        NumberAxis numberaxis = (NumberAxis)xyplot.getDomainAxis();
        numberaxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        return jfreechart;
    }

    private static IntervalXYDataset createDataset()
    {
        XYSeries xyseries = new XYSeries("Series 1");
        xyseries.add(1.0D, 5D);
        xyseries.add(2D, 7.7999999999999998D);
        xyseries.add(3D, 9.3000000000000007D);
        XYSeriesCollection xyseriescollection = new XYSeriesCollection();
        xyseriescollection.addSeries(xyseries);
        return new XYBarDataset(xyseriescollection, 0.90000000000000002D);
    }

    public static JPanel createDemoPanel()
    {
        return new ChartPanel(createChart(new SimpleIntervalXYDataset()));
    }

    public static void main(String args[])
    {
        XYBarChartDemo4 xybarchartdemo4 = new XYBarChartDemo4("XY Bar Chart Demo 4");
        xybarchartdemo4.pack();
        RefineryUtilities.centerFrameOnScreen(xybarchartdemo4);
        xybarchartdemo4.setVisible(true);
    }
}