// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 7/18/2005 5:13:40 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 

package org.jfree.chart.demo;

import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JPanel;
import org.jfree.chart.*;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.xy.XYZDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

// Referenced classes of package demo:
//            SampleXYZDataset

public class BubbleChartDemo1 extends ApplicationFrame
{

    public BubbleChartDemo1(String s)
    {
        super(s);
        SampleXYZDataset samplexyzdataset = new SampleXYZDataset();
        JFreeChart jfreechart = createChart(samplexyzdataset);
        ChartPanel chartpanel = new ChartPanel(jfreechart);
        chartpanel.setPreferredSize(new Dimension(500, 270));
        chartpanel.setDomainZoomable(true);
        chartpanel.setRangeZoomable(true);
        setContentPane(chartpanel);
    }

    private static JFreeChart createChart(XYZDataset xyzdataset)
    {
        JFreeChart jfreechart = ChartFactory.createBubbleChart("Bubble Chart Demo 1", "X", "Y", xyzdataset, PlotOrientation.HORIZONTAL, true, true, false);
        XYPlot xyplot = (XYPlot)jfreechart.getPlot();
        xyplot.setForegroundAlpha(0.65F);
        XYItemRenderer xyitemrenderer = xyplot.getRenderer();
        xyitemrenderer.setSeriesPaint(0, Color.blue);
        NumberAxis numberaxis = (NumberAxis)xyplot.getDomainAxis();
        numberaxis.setLowerMargin(0.14999999999999999D);
        numberaxis.setUpperMargin(0.14999999999999999D);
        NumberAxis numberaxis1 = (NumberAxis)xyplot.getRangeAxis();
        numberaxis1.setLowerMargin(0.14999999999999999D);
        numberaxis1.setUpperMargin(0.14999999999999999D);
        return jfreechart;
    }

    public static JPanel createDemoPanel()
    {
        JFreeChart jfreechart = createChart(new SampleXYZDataset());
        return new ChartPanel(jfreechart);
    }

    public static void main(String args[])
    {
        BubbleChartDemo1 bubblechartdemo1 = new BubbleChartDemo1("Bubble Chart Demo 1");
        bubblechartdemo1.pack();
        RefineryUtilities.centerFrameOnScreen(bubblechartdemo1);
        bubblechartdemo1.setVisible(true);
    }
}