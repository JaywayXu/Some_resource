// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 7/18/2005 5:13:55 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 

package org.jfree.chart.demo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;
import org.jfree.chart.plot.PiePlot3D;

class Rotator extends Timer
    implements ActionListener
{

    Rotator(PiePlot3D pieplot3d)
    {
        super(100, null);
        angle = 270;
        plot = pieplot3d;
        addActionListener(this);
    }

    public void actionPerformed(ActionEvent actionevent)
    {
        plot.setStartAngle(angle);
        angle = angle + 1;
        if(angle == 360)
            angle = 0;
    }

    private PiePlot3D plot;
    private int angle;
}