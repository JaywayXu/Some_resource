// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 7/18/2005 5:14:02 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 

package org.jfree.chart.demo;

import java.awt.*;
import javax.swing.JPanel;
import org.jfree.chart.*;
import org.jfree.data.xy.DefaultWindDataset;
import org.jfree.data.xy.WindDataset;
import org.jfree.date.DateUtilities;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class WindChartDemo1 extends ApplicationFrame
{

    public WindChartDemo1(String s)
    {
        super(s);
        WindDataset winddataset = createDataset();
        JFreeChart jfreechart = createChart(winddataset);
        ChartPanel chartpanel = new ChartPanel(jfreechart);
        chartpanel.setPreferredSize(new Dimension(500, 270));
        setContentPane(chartpanel);
    }

    public static WindDataset createDataset()
    {
        int i = 1;
        Object aobj[][][] = {
            {
                {
                    DateUtilities.createDate(1999, i, 3), new Double(0.0D), new Double(10D)
                }, {
                    DateUtilities.createDate(1999, i, 4), new Double(1.0D), new Double(8.5D)
                }, {
                    DateUtilities.createDate(1999, i, 5), new Double(2D), new Double(10D)
                }, {
                    DateUtilities.createDate(1999, i, 6), new Double(3D), new Double(10D)
                }, {
                    DateUtilities.createDate(1999, i, 7), new Double(4D), new Double(7D)
                }, {
                    DateUtilities.createDate(1999, i, 8), new Double(5D), new Double(10D)
                }, {
                    DateUtilities.createDate(1999, i, 9), new Double(6D), new Double(8D)
                }, {
                    DateUtilities.createDate(1999, i, 10), new Double(7D), new Double(11D)
                }, {
                    DateUtilities.createDate(1999, i, 11), new Double(8D), new Double(10D)
                }, {
                    DateUtilities.createDate(1999, i, 12), new Double(9D), new Double(11D)
                }, {
                    DateUtilities.createDate(1999, i, 13), new Double(10D), new Double(3D)
                }, {
                    DateUtilities.createDate(1999, i, 14), new Double(11D), new Double(9D)
                }, {
                    DateUtilities.createDate(1999, i, 15), new Double(12D), new Double(11D)
                }, {
                    DateUtilities.createDate(1999, i, 16), new Double(0.0D), new Double(0.0D)
                }
            }
        };
        return new DefaultWindDataset(new String[] {
            "Wind!!"
        }, aobj);
    }

    private static JFreeChart createChart(WindDataset winddataset)
    {
        JFreeChart jfreechart = ChartFactory.createWindPlot("Wind Chart Demo", "Date", "Direction / Force", winddataset, true, false, false);
        jfreechart.setBackgroundPaint(new GradientPaint(0.0F, 0.0F, Color.white, 1000F, 0.0F, Color.green));
        return jfreechart;
    }

    public static JPanel createDemoPanel()
    {
        return new ChartPanel(createChart(createDataset()));
    }

    public static void main(String args[])
    {
        WindChartDemo1 windchartdemo1 = new WindChartDemo1("Wind Chart Demo");
        windchartdemo1.pack();
        RefineryUtilities.centerFrameOnScreen(windchartdemo1);
        windchartdemo1.setVisible(true);
    }
}