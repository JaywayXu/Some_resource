// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 7/18/2005 5:13:56 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 

package org.jfree.chart.demo;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;
import java.io.PrintStream;
import org.jfree.chart.*;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.*;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

// Referenced classes of package demo:
//            SampleXYDataset2

public class ScatterPlotDemo3 extends ApplicationFrame
    implements ChartMouseListener
{

    public ScatterPlotDemo3(String s)
    {
        super(s);
        SampleXYDataset2 samplexydataset2 = new SampleXYDataset2();
        JFreeChart jfreechart = createChart(samplexydataset2);
        chartPanel = new ChartPanel(jfreechart);
        chartPanel.addChartMouseListener(this);
        chartPanel.setPreferredSize(new Dimension(500, 270));
        chartPanel.setVerticalAxisTrace(true);
        chartPanel.setHorizontalAxisTrace(true);
        chartPanel.setDomainZoomable(true);
        chartPanel.setRangeZoomable(true);
        setContentPane(chartPanel);
    }

    private JFreeChart createChart(XYDataset xydataset)
    {
        JFreeChart jfreechart = ChartFactory.createScatterPlot("Scatter Plot Demo", "X", "Y", xydataset, PlotOrientation.VERTICAL, true, true, false);
        NumberAxis numberaxis = (NumberAxis)jfreechart.getXYPlot().getDomainAxis();
        numberaxis.setAutoRangeIncludesZero(false);
        return jfreechart;
    }

    public void chartMouseClicked(ChartMouseEvent chartmouseevent)
    {
        int i = chartmouseevent.getTrigger().getX();
        int j = chartmouseevent.getTrigger().getY();
        Point2D point2d = chartPanel.translateScreenToJava2D(new Point(i, j));
        XYPlot xyplot = (XYPlot)chartPanel.getChart().getPlot();
        ChartRenderingInfo chartrenderinginfo = chartPanel.getChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2d = chartrenderinginfo.getPlotInfo().getDataArea();
        double d = xyplot.getDomainAxis().java2DToValue(point2d.getX(), rectangle2d, xyplot.getDomainAxisEdge());
        double d1 = xyplot.getRangeAxis().java2DToValue(point2d.getY(), rectangle2d, xyplot.getRangeAxisEdge());
        ValueAxis valueaxis = xyplot.getDomainAxis();
        ValueAxis valueaxis1 = xyplot.getRangeAxis();
        double d2 = valueaxis.valueToJava2D(d, rectangle2d, xyplot.getDomainAxisEdge());
        double d3 = valueaxis1.valueToJava2D(d1, rectangle2d, xyplot.getRangeAxisEdge());
        Point point = chartPanel.translateJava2DToScreen(new java.awt.geom.Point2D.Double(d2, d3));
        System.out.println("Mouse coordinates are (" + i + ", " + j + "), in data space = (" + d + ", " + d1 + ").");
        System.out.println("--> (" + point.getX() + ", " + point.getY() + ")");
    }

    public void chartMouseMoved(ChartMouseEvent chartmouseevent)
    {
    }

    public static void main(String args[])
    {
        ScatterPlotDemo3 scatterplotdemo3 = new ScatterPlotDemo3("Scatter Plot Demo 3");
        scatterplotdemo3.pack();
        RefineryUtilities.centerFrameOnScreen(scatterplotdemo3);
        scatterplotdemo3.setVisible(true);
    }

    private ChartPanel chartPanel;
}