// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 7/18/2005 5:13:52 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 

package org.jfree.chart.demo;

import java.awt.Color;
import java.awt.Dimension;
import java.text.NumberFormat;
import org.jfree.chart.*;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.*;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.DataUtilities;
import org.jfree.data.DefaultKeyedValues;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import org.jfree.util.SortOrder;

public class ParetoChartDemo extends ApplicationFrame
{

    public ParetoChartDemo(String s)
    {
        super(s);
        DefaultKeyedValues defaultkeyedvalues = new DefaultKeyedValues();
        defaultkeyedvalues.addValue("C", new Integer(4843));
        defaultkeyedvalues.addValue("C++", new Integer(2098));
        defaultkeyedvalues.addValue("C#", new Integer(26));
        defaultkeyedvalues.addValue("Java", new Integer(1901));
        defaultkeyedvalues.addValue("Perl", new Integer(2507));
        defaultkeyedvalues.addValue("PHP", new Integer(1689));
        defaultkeyedvalues.addValue("Python", new Integer(948));
        defaultkeyedvalues.addValue("Ruby", new Integer(100));
        defaultkeyedvalues.addValue("SQL", new Integer(263));
        defaultkeyedvalues.addValue("Unix Shell", new Integer(485));
        defaultkeyedvalues.sortByValues(SortOrder.DESCENDING);
        org.jfree.data.KeyedValues keyedvalues = DataUtilities.getCumulativePercentages(defaultkeyedvalues);
        org.jfree.data.category.CategoryDataset categorydataset = DatasetUtilities.createCategoryDataset("Languages", defaultkeyedvalues);
        JFreeChart jfreechart = ChartFactory.createBarChart("Freshmeat Software Projects", "Language", "Projects", categorydataset, PlotOrientation.VERTICAL, true, true, false);
        jfreechart.addSubtitle(new TextTitle("By Programming Language"));
        jfreechart.addSubtitle(new TextTitle("As at 5 March 2003"));
        jfreechart.setBackgroundPaint(Color.white);
        CategoryPlot categoryplot = jfreechart.getCategoryPlot();
        categoryplot.setBackgroundPaint(Color.lightGray);
        categoryplot.setRangeGridlinePaint(Color.white);
        CategoryAxis categoryaxis = categoryplot.getDomainAxis();
        categoryaxis.setLowerMargin(0.02D);
        categoryaxis.setUpperMargin(0.02D);
        NumberAxis numberaxis = (NumberAxis)categoryplot.getRangeAxis();
        numberaxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        LineAndShapeRenderer lineandshaperenderer = new LineAndShapeRenderer();
        org.jfree.data.category.CategoryDataset categorydataset1 = DatasetUtilities.createCategoryDataset("Cumulative", keyedvalues);
        NumberAxis numberaxis1 = new NumberAxis("Percent");
        numberaxis1.setNumberFormatOverride(NumberFormat.getPercentInstance());
        categoryplot.setRangeAxis(1, numberaxis1);
        categoryplot.setDataset(1, categorydataset1);
        categoryplot.setRenderer(1, lineandshaperenderer);
        categoryplot.mapDatasetToRangeAxis(1, 1);
        categoryplot.setDatasetRenderingOrder(DatasetRenderingOrder.FORWARD);
        ChartPanel chartpanel = new ChartPanel(jfreechart);
        chartpanel.setPreferredSize(new Dimension(550, 270));
        setContentPane(chartpanel);
    }

    public static void main(String args[])
    {
        ParetoChartDemo paretochartdemo = new ParetoChartDemo("Pareto Chart Demo");
        paretochartdemo.pack();
        RefineryUtilities.centerFrameOnScreen(paretochartdemo);
        paretochartdemo.setVisible(true);
    }
}