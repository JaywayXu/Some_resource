// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 7/18/2005 5:13:50 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 

package org.jfree.chart.demo;

import java.awt.Color;
import java.awt.Dimension;
import org.jfree.chart.*;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.MinMaxCategoryRenderer;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class MinMaxCategoryPlotDemo extends ApplicationFrame
{

    public MinMaxCategoryPlotDemo(String s)
    {
        super(s);
        DefaultCategoryDataset defaultcategorydataset = new DefaultCategoryDataset();
        defaultcategorydataset.addValue(1.0D, "First", "Category 1");
        defaultcategorydataset.addValue(4D, "First", "Category 2");
        defaultcategorydataset.addValue(3D, "First", "Category 3");
        defaultcategorydataset.addValue(5D, "First", "Category 4");
        defaultcategorydataset.addValue(5D, "First", "Category 5");
        defaultcategorydataset.addValue(7D, "First", "Category 6");
        defaultcategorydataset.addValue(7D, "First", "Category 7");
        defaultcategorydataset.addValue(8D, "First", "Category 8");
        defaultcategorydataset.addValue(5D, "Second", "Category 1");
        defaultcategorydataset.addValue(7D, "Second", "Category 2");
        defaultcategorydataset.addValue(6D, "Second", "Category 3");
        defaultcategorydataset.addValue(8D, "Second", "Category 4");
        defaultcategorydataset.addValue(4D, "Second", "Category 5");
        defaultcategorydataset.addValue(4D, "Second", "Category 6");
        defaultcategorydataset.addValue(2D, "Second", "Category 7");
        defaultcategorydataset.addValue(1.0D, "Second", "Category 8");
        defaultcategorydataset.addValue(4D, "Third", "Category 1");
        defaultcategorydataset.addValue(3D, "Third", "Category 2");
        defaultcategorydataset.addValue(2D, "Third", "Category 3");
        defaultcategorydataset.addValue(3D, "Third", "Category 4");
        defaultcategorydataset.addValue(6D, "Third", "Category 5");
        defaultcategorydataset.addValue(3D, "Third", "Category 6");
        defaultcategorydataset.addValue(4D, "Third", "Category 7");
        defaultcategorydataset.addValue(3D, "Third", "Category 8");
        JFreeChart jfreechart = ChartFactory.createBarChart("Min/Max Category Plot", "Category", "Value", defaultcategorydataset, PlotOrientation.VERTICAL, true, true, false);
        jfreechart.setBackgroundPaint(Color.yellow);
        CategoryPlot categoryplot = jfreechart.getCategoryPlot();
        categoryplot.setRenderer(new MinMaxCategoryRenderer());
        ChartPanel chartpanel = new ChartPanel(jfreechart);
        chartpanel.setPreferredSize(new Dimension(500, 270));
        setContentPane(chartpanel);
    }

    public static void main(String args[])
    {
        MinMaxCategoryPlotDemo minmaxcategoryplotdemo = new MinMaxCategoryPlotDemo("Min/Max Category Chart Demo");
        minmaxcategoryplotdemo.pack();
        RefineryUtilities.centerFrameOnScreen(minmaxcategoryplotdemo);
        minmaxcategoryplotdemo.setVisible(true);
    }
}