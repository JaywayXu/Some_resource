// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 7/18/2005 5:13:51 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 

package org.jfree.chart.demo;

import java.awt.Dimension;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.function.NormalDistributionFunction2D;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class NormalDistributionDemo extends ApplicationFrame
{

    public NormalDistributionDemo(String s)
    {
        super(s);
        NormalDistributionFunction2D normaldistributionfunction2d = new NormalDistributionFunction2D(10.07D, 3.47D);
        org.jfree.data.xy.XYDataset xydataset = DatasetUtilities.sampleFunction2D(normaldistributionfunction2d, 0D, 50D, 50, "Normal");
        org.jfree.chart.JFreeChart jfreechart = ChartFactory.createXYLineChart("XY Series Demo", "X", "Y", xydataset, PlotOrientation.VERTICAL, true, true, false);
        ChartPanel chartpanel = new ChartPanel(jfreechart);
        chartpanel.setPreferredSize(new Dimension(500, 270));
        setContentPane(chartpanel);
    }

    public static void main(String args[])
    {
        NormalDistributionDemo normaldistributiondemo = new NormalDistributionDemo("Normal Distribution Demo");
        normaldistributiondemo.pack();
        RefineryUtilities.centerFrameOnScreen(normaldistributiondemo);
        normaldistributiondemo.setVisible(true);
    }
}