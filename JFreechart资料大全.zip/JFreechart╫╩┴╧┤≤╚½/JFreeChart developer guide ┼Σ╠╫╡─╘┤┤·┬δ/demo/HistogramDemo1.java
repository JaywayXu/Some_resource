// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 7/18/2005 5:13:46 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 

package org.jfree.chart.demo;

import java.awt.Dimension;
import java.io.IOException;
import org.jfree.chart.*;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.statistics.HistogramDataset;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class HistogramDemo1 extends ApplicationFrame
{

    public HistogramDemo1(String s)
    {
        super(s);
        IntervalXYDataset intervalxydataset = createDataset();
        JFreeChart jfreechart = createChart(intervalxydataset);
        ChartPanel chartpanel = new ChartPanel(jfreechart);
        chartpanel.setPreferredSize(new Dimension(500, 270));
        setContentPane(chartpanel);
    }

    private IntervalXYDataset createDataset()
    {
        HistogramDataset histogramdataset = new HistogramDataset();
        double ad[] = {
            1.0D, 2D, 3D, 4D, 5D, 6D, 7D, 8D, 9D, 10D
        };
        histogramdataset.addSeries("H1", ad, 10, 0.0D, 10D);
        return histogramdataset;
    }

    private JFreeChart createChart(IntervalXYDataset intervalxydataset)
    {
        JFreeChart jfreechart = ChartFactory.createHistogram("Histogram Demo", null, null, intervalxydataset, PlotOrientation.VERTICAL, true, false, false);
        jfreechart.getXYPlot().setForegroundAlpha(0.75F);
        return jfreechart;
    }

    public static void main(String args[])
        throws IOException
    {
        HistogramDemo1 histogramdemo1 = new HistogramDemo1("Histogram Demo 1");
        histogramdemo1.pack();
        RefineryUtilities.centerFrameOnScreen(histogramdemo1);
        histogramdemo1.setVisible(true);
    }
}