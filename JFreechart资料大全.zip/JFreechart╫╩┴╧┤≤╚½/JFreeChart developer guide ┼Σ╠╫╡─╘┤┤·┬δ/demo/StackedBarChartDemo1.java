// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 7/18/2005 5:13:57 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 

package org.jfree.chart.demo;

import java.awt.Dimension;
import org.jfree.chart.*;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class StackedBarChartDemo1 extends ApplicationFrame
{

    public StackedBarChartDemo1(String s)
    {
        super(s);
        CategoryDataset categorydataset = createDataset();
        JFreeChart jfreechart = createChart(categorydataset);
        ChartPanel chartpanel = new ChartPanel(jfreechart);
        chartpanel.setPreferredSize(new Dimension(500, 270));
        setContentPane(chartpanel);
    }

    private CategoryDataset createDataset()
    {
        double ad[][] = {
            {
                10D, 4D, 15D, 14D
            }, {
                -5D, -7D, 14D, -3D
            }, {
                6D, 17D, -12D, 7D
            }, {
                7D, 15D, 11D, 0.0D
            }, {
                -8D, -6D, 10D, -9D
            }, {
                9D, 8D, 0.0D, 6D
            }, {
                -10D, 9D, 7D, 7D
            }, {
                11D, 13D, 9D, 9D
            }, {
                -3D, 7D, 11D, -10D
            }
        };
        return DatasetUtilities.createCategoryDataset("Series ", "Category ", ad);
    }

    private JFreeChart createChart(CategoryDataset categorydataset)
    {
        JFreeChart jfreechart = ChartFactory.createStackedBarChart("Stacked Bar Chart Demo 1", "Category", "Value", categorydataset, PlotOrientation.VERTICAL, true, true, false);
        CategoryPlot categoryplot = (CategoryPlot)jfreechart.getPlot();
        CategoryItemRenderer categoryitemrenderer = categoryplot.getRenderer();
        categoryitemrenderer.setItemLabelGenerator(new StandardCategoryItemLabelGenerator());
        categoryitemrenderer.setItemLabelsVisible(true);
        return jfreechart;
    }

    public static void main(String args[])
    {
        StackedBarChartDemo1 stackedbarchartdemo1 = new StackedBarChartDemo1("Stacked Bar Chart Demo 1");
        stackedbarchartdemo1.pack();
        RefineryUtilities.centerFrameOnScreen(stackedbarchartdemo1);
        stackedbarchartdemo1.setVisible(true);
    }
}