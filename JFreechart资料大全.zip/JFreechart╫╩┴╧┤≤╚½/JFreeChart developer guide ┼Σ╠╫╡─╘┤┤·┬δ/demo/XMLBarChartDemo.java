// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 7/18/2005 5:14:02 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 

package org.jfree.chart.demo;

import java.awt.Color;
import java.awt.Dimension;
import java.io.IOException;
import java.io.PrintStream;
import java.net.URL;
import org.jfree.chart.*;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xml.DatasetReader;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class XMLBarChartDemo extends ApplicationFrame
{

    public XMLBarChartDemo(String s)
    {
        super(s);
        org.jfree.data.category.CategoryDataset categorydataset = null;
        URL url = getClass().getResource("/org/jfree/chart/demo/categorydata.xml");
        try
        {
            java.io.InputStream inputstream = url.openStream();
            categorydataset = DatasetReader.readCategoryDatasetFromXML(inputstream);
        }
        catch(IOException ioexception)
        {
            System.out.println(ioexception.getMessage());
        }
        JFreeChart jfreechart = ChartFactory.createBarChart("Bar Chart", "Domain", "Range", categorydataset, PlotOrientation.VERTICAL, true, true, false);
        jfreechart.setBackgroundPaint(Color.yellow);
        ChartPanel chartpanel = new ChartPanel(jfreechart);
        chartpanel.setPreferredSize(new Dimension(500, 270));
        setContentPane(chartpanel);
    }

    public static void main(String args[])
    {
        XMLBarChartDemo xmlbarchartdemo = new XMLBarChartDemo("XML Bar Chart Demo");
        xmlbarchartdemo.pack();
        RefineryUtilities.centerFrameOnScreen(xmlbarchartdemo);
        xmlbarchartdemo.setVisible(true);
    }
}