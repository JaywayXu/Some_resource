// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 7/18/2005 5:13:38 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 

package org.jfree.chart.demo;

import java.awt.Dimension;
import javax.swing.JPanel;
import org.jfree.chart.*;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.YIntervalRenderer;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

// Referenced classes of package demo:
//            SimpleIntervalXYDataset2

public class YIntervalChartDemo1 extends ApplicationFrame
{

    public YIntervalChartDemo1(String s)
    {
        super(s);
        SimpleIntervalXYDataset2 simpleintervalxydataset2 = new SimpleIntervalXYDataset2(100);
        JFreeChart jfreechart = createChart(simpleintervalxydataset2);
        ChartPanel chartpanel = new ChartPanel(jfreechart);
        chartpanel.setPreferredSize(new Dimension(500, 300));
        setContentPane(chartpanel);
    }

    private static JFreeChart createChart(IntervalXYDataset intervalxydataset)
    {
        JFreeChart jfreechart = ChartFactory.createScatterPlot("Y Interval Chart Demo", "X", "Y", intervalxydataset, PlotOrientation.VERTICAL, true, true, false);
        XYPlot xyplot = jfreechart.getXYPlot();
        xyplot.setRenderer(new YIntervalRenderer());
        return jfreechart;
    }

    public static JPanel createDemoPanel()
    {
        JFreeChart jfreechart = createChart(new SimpleIntervalXYDataset2(100));
        return new ChartPanel(jfreechart);
    }

    public static void main(String args[])
    {
        YIntervalChartDemo1 yintervalchartdemo1 = new YIntervalChartDemo1("Y Interval Chart Demo");
        yintervalchartdemo1.pack();
        RefineryUtilities.centerFrameOnScreen(yintervalchartdemo1);
        yintervalchartdemo1.setVisible(true);
    }
}