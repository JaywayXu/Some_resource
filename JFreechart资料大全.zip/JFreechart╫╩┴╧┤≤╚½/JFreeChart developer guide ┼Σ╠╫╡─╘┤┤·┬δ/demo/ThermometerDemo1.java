// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 7/18/2005 5:13:59 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 

package org.jfree.chart.demo;

import java.awt.BasicStroke;
import java.awt.Color;
import javax.swing.JPanel;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.ThermometerPlot;
import org.jfree.data.general.DefaultValueDataset;
import org.jfree.data.general.ValueDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RectangleInsets;

public class ThermometerDemo1 extends ApplicationFrame
{

    public ThermometerDemo1(String s)
    {
        super(s);
        DefaultValueDataset defaultvaluedataset = new DefaultValueDataset(new Double(43D));
        JFreeChart jfreechart = createChart(defaultvaluedataset);
        ChartPanel chartpanel = new ChartPanel(jfreechart);
        setContentPane(chartpanel);
    }

    private static JFreeChart createChart(ValueDataset valuedataset)
    {
        ThermometerPlot thermometerplot = new ThermometerPlot(valuedataset);
        JFreeChart jfreechart = new JFreeChart("Thermometer Demo 1", JFreeChart.DEFAULT_TITLE_FONT, thermometerplot, false);
        thermometerplot.setInsets(new RectangleInsets(5D, 5D, 5D, 5D));
        thermometerplot.setThermometerStroke(new BasicStroke(2.0F));
        thermometerplot.setThermometerPaint(Color.lightGray);
        return jfreechart;
    }

    public static JPanel createDemoPanel()
    {
        JFreeChart jfreechart = createChart(new DefaultValueDataset(new Double(43D)));
        return new ChartPanel(jfreechart);
    }

    public static void main(String args[])
    {
        ThermometerDemo1 thermometerdemo1 = new ThermometerDemo1("Thermometer Demo 1");
        thermometerdemo1.pack();
        thermometerdemo1.setVisible(true);
    }
}