// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 7/18/2005 5:13:54 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 

package org.jfree.chart.demo;

import java.awt.Dimension;
import org.jfree.chart.*;
import org.jfree.chart.labels.PieSectionLabelGenerator;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class PieChartDemo6 extends ApplicationFrame
{
    static class CustomLabelGenerator
        implements PieSectionLabelGenerator
    {

        public String generateSectionLabel(PieDataset piedataset, Comparable comparable)
        {
            String s = null;
            if(piedataset != null && !comparable.equals("Two"))
                s = comparable.toString();
            return s;
        }

        CustomLabelGenerator()
        {
        }
    }


    public PieChartDemo6(String s)
    {
        super(s);
        PieDataset piedataset = createDataset();
        JFreeChart jfreechart = createChart(piedataset);
        ChartPanel chartpanel = new ChartPanel(jfreechart);
        chartpanel.setPreferredSize(new Dimension(500, 270));
        setContentPane(chartpanel);
    }

    private PieDataset createDataset()
    {
        DefaultPieDataset defaultpiedataset = new DefaultPieDataset();
        defaultpiedataset.setValue("One", new Double(43.200000000000003D));
        defaultpiedataset.setValue("Two", new Double(10D));
        defaultpiedataset.setValue("Three", new Double(27.5D));
        defaultpiedataset.setValue("Four", new Double(17.5D));
        defaultpiedataset.setValue("Five", new Double(11D));
        defaultpiedataset.setValue("Six", new Double(19.399999999999999D));
        return defaultpiedataset;
    }

    private JFreeChart createChart(PieDataset piedataset)
    {
        JFreeChart jfreechart = ChartFactory.createPieChart("Pie Chart Demo 6", piedataset, false, true, false);
        PiePlot pieplot = (PiePlot)jfreechart.getPlot();
        pieplot.setLabelGenerator(new CustomLabelGenerator());
        return jfreechart;
    }

    public static void main(String args[])
    {
        PieChartDemo6 piechartdemo6 = new PieChartDemo6("Pie Chart Demo 6");
        piechartdemo6.pack();
        RefineryUtilities.centerFrameOnScreen(piechartdemo6);
        piechartdemo6.setVisible(true);
    }
}