// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 7/18/2005 5:13:58 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 

package org.jfree.chart.demo;

import java.awt.Dimension;
import org.jfree.chart.*;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.*;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class StackedXYAreaChartDemo1 extends ApplicationFrame
{

    public StackedXYAreaChartDemo1(String s)
    {
        super(s);
        TableXYDataset tablexydataset = createDataset();
        JFreeChart jfreechart = createChart(tablexydataset);
        ChartPanel chartpanel = new ChartPanel(jfreechart);
        chartpanel.setPreferredSize(new Dimension(500, 270));
        setContentPane(chartpanel);
    }

    private TableXYDataset createDataset()
    {
        DefaultTableXYDataset defaulttablexydataset = new DefaultTableXYDataset();
        XYSeries xyseries = new XYSeries("Series 1", true, false);
        xyseries.add(5D, 5D);
        xyseries.add(10D, 15.5D);
        xyseries.add(15D, 9.5D);
        xyseries.add(20D, 7.5D);
        defaulttablexydataset.addSeries(xyseries);
        XYSeries xyseries1 = new XYSeries("Series 2", true, false);
        xyseries1.add(5D, 5D);
        xyseries1.add(10D, 15.5D);
        xyseries1.add(15D, 9.5D);
        xyseries1.add(20D, 3.5D);
        defaulttablexydataset.addSeries(xyseries1);
        return defaulttablexydataset;
    }

    private JFreeChart createChart(TableXYDataset tablexydataset)
    {
        JFreeChart jfreechart = ChartFactory.createStackedXYAreaChart("Stacked XY Area Chart Demo 1", "Category", "Value", tablexydataset, PlotOrientation.VERTICAL, true, true, false);
        return jfreechart;
    }

    public static void main(String args[])
    {
        StackedXYAreaChartDemo1 stackedxyareachartdemo1 = new StackedXYAreaChartDemo1("Stacked XY Area Chart Demo 1");
        stackedxyareachartdemo1.pack();
        RefineryUtilities.centerFrameOnScreen(stackedxyareachartdemo1);
        stackedxyareachartdemo1.setVisible(true);
    }
}