// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 7/18/2005 5:13:39 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 

package org.jfree.chart.demo;

import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JPanel;
import org.jfree.chart.*;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class BarChartDemo5 extends ApplicationFrame
{

    public BarChartDemo5(String s)
    {
        super(s);
        CategoryDataset categorydataset = createDataset();
        JFreeChart jfreechart = createChart(categorydataset);
        ChartPanel chartpanel = new ChartPanel(jfreechart);
        chartpanel.setPreferredSize(new Dimension(500, 270));
        setContentPane(chartpanel);
    }

    private static CategoryDataset createDataset()
    {
        double ad[][] = {
            {
                1.0D, 43D, 35D, 58D, 54D, 77D, 71D, 89D
            }, {
                54D, 75D, 63D, 83D, 43D, 46D, 27D, 13D
            }, {
                41D, 33D, 22D, 34D, 62D, 32D, 42D, 34D
            }
        };
        return DatasetUtilities.createCategoryDataset("Series ", "Factor ", ad);
    }

    private static JFreeChart createChart(CategoryDataset categorydataset)
    {
        JFreeChart jfreechart = ChartFactory.createBarChart("Bar Chart", "Category", "Score (%)", categorydataset, PlotOrientation.HORIZONTAL, true, true, false);
        CategoryPlot categoryplot = jfreechart.getCategoryPlot();
        categoryplot.getRenderer().setSeriesPaint(0, new Color(0, 0, 255));
        categoryplot.getRenderer().setSeriesPaint(1, new Color(75, 75, 255));
        categoryplot.getRenderer().setSeriesPaint(2, new Color(150, 150, 255));
        NumberAxis numberaxis = (NumberAxis)categoryplot.getRangeAxis();
        numberaxis.setRange(0.0D, 100D);
        numberaxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        return jfreechart;
    }

    public static JPanel createDemoPanel()
    {
        JFreeChart jfreechart = createChart(createDataset());
        return new ChartPanel(jfreechart);
    }

    public static void main(String args[])
    {
        BarChartDemo5 barchartdemo5 = new BarChartDemo5("Bar Chart Demo 5");
        barchartdemo5.pack();
        RefineryUtilities.centerFrameOnScreen(barchartdemo5);
        barchartdemo5.setVisible(true);
    }
}