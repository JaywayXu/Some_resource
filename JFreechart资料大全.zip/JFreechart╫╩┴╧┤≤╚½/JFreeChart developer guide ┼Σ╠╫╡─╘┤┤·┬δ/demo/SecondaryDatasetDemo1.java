// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 7/18/2005 5:13:56 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 

package org.jfree.chart.demo;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;
import org.jfree.chart.*;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.*;

public class SecondaryDatasetDemo1 extends ApplicationFrame
    implements ActionListener
{

    public SecondaryDatasetDemo1(String s)
    {
        super(s);
        secondaryDatasetIndex = 0;
        CategoryDataset categorydataset = createRandomDataset("Series 1");
        JFreeChart jfreechart = ChartFactory.createLineChart("Secondary Dataset Demo 2", "Category", "Value", categorydataset, PlotOrientation.VERTICAL, true, true, false);
        jfreechart.setBackgroundPaint(Color.white);
        plot = jfreechart.getCategoryPlot();
        plot.setBackgroundPaint(Color.lightGray);
        plot.setDomainGridlinePaint(Color.white);
        plot.setRangeGridlinePaint(Color.white);
        plot.setAxisOffset(new RectangleInsets(4D, 4D, 4D, 4D));
        NumberAxis numberaxis = (NumberAxis)plot.getRangeAxis();
        numberaxis.setAutoRangeIncludesZero(false);
        JPanel jpanel = new JPanel(new BorderLayout());
        ChartPanel chartpanel = new ChartPanel(jfreechart);
        jpanel.add(chartpanel);
        JButton jbutton = new JButton("Add Dataset");
        jbutton.setActionCommand("ADD_DATASET");
        jbutton.addActionListener(this);
        JButton jbutton1 = new JButton("Remove Dataset");
        jbutton1.setActionCommand("REMOVE_DATASET");
        jbutton1.addActionListener(this);
        JPanel jpanel1 = new JPanel(new FlowLayout());
        jpanel1.add(jbutton);
        jpanel1.add(jbutton1);
        jpanel.add(jpanel1, "South");
        chartpanel.setPreferredSize(new Dimension(500, 270));
        setContentPane(jpanel);
    }

    private CategoryDataset createRandomDataset(String s)
    {
        DefaultCategoryDataset defaultcategorydataset = new DefaultCategoryDataset();
        double d = 100D;
        for(int i = 0; i < 10; i++)
        {
            String s1 = "T" + i;
            d *= 1.0D + Math.random() / 100D;
            defaultcategorydataset.addValue(d, s, s1);
        }

        return defaultcategorydataset;
    }

    public void actionPerformed(ActionEvent actionevent)
    {
        if(actionevent.getActionCommand().equals("ADD_DATASET"))
        {
            if(secondaryDatasetIndex < 20)
            {
                secondaryDatasetIndex++;
                plot.setDataset(secondaryDatasetIndex, createRandomDataset("S" + secondaryDatasetIndex));
                plot.setRenderer(secondaryDatasetIndex, new LineAndShapeRenderer(true, false));
            }
        } else
        if(actionevent.getActionCommand().equals("REMOVE_DATASET") && secondaryDatasetIndex > 0)
        {
            plot.setDataset(secondaryDatasetIndex, null);
            plot.setRenderer(secondaryDatasetIndex, null);
            secondaryDatasetIndex--;
        }
    }

    public static void main(String args[])
    {
        SecondaryDatasetDemo1 secondarydatasetdemo1 = new SecondaryDatasetDemo1("Secondary Dataset Demo 2");
        secondarydatasetdemo1.pack();
        RefineryUtilities.centerFrameOnScreen(secondarydatasetdemo1);
        secondarydatasetdemo1.setVisible(true);
    }

    private CategoryPlot plot;
    private int secondaryDatasetIndex;
}