// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 7/18/2005 5:13:54 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 

package org.jfree.chart.demo;

import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.JPanel;
import org.jfree.chart.*;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.PiePlot3D;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class PieChartDemo7 extends ApplicationFrame
{

    public PieChartDemo7(String s)
    {
        super(s);
        JPanel jpanel = new JPanel(new GridLayout(2, 2));
        DefaultPieDataset defaultpiedataset = new DefaultPieDataset();
        defaultpiedataset.setValue("Section 1", 23.300000000000001D);
        defaultpiedataset.setValue("Section 2", 56.5D);
        defaultpiedataset.setValue("Section 3", 43.299999999999997D);
        defaultpiedataset.setValue("Section 4", 11.1D);
        JFreeChart jfreechart = ChartFactory.createPieChart("Chart 1", defaultpiedataset, false, false, false);
        JFreeChart jfreechart1 = ChartFactory.createPieChart("Chart 2", defaultpiedataset, false, false, false);
        PiePlot pieplot = (PiePlot)jfreechart1.getPlot();
        pieplot.setCircular(false);
        JFreeChart jfreechart2 = ChartFactory.createPieChart3D("Chart 3", defaultpiedataset, false, false, false);
        PiePlot3D pieplot3d = (PiePlot3D)jfreechart2.getPlot();
        pieplot3d.setForegroundAlpha(0.6F);
        pieplot3d.setCircular(true);
        JFreeChart jfreechart3 = ChartFactory.createPieChart3D("Chart 4", defaultpiedataset, false, false, false);
        PiePlot3D pieplot3d1 = (PiePlot3D)jfreechart3.getPlot();
        pieplot3d1.setForegroundAlpha(0.6F);
        jpanel.add(new ChartPanel(jfreechart));
        jpanel.add(new ChartPanel(jfreechart1));
        jpanel.add(new ChartPanel(jfreechart2));
        jpanel.add(new ChartPanel(jfreechart3));
        jpanel.setPreferredSize(new Dimension(800, 600));
        setContentPane(jpanel);
    }

    public static void main(String args[])
    {
        PieChartDemo7 piechartdemo7 = new PieChartDemo7("Pie Chart Demo 7");
        piechartdemo7.pack();
        RefineryUtilities.centerFrameOnScreen(piechartdemo7);
        piechartdemo7.setVisible(true);
    }
}