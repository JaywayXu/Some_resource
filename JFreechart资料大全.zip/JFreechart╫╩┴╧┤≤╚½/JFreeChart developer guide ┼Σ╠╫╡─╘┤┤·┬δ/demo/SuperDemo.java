// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 8/14/2005 10:56:19 AM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 

package org.jfree.chart.demo;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import javax.swing.*;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.*;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

// Referenced classes of package demo:
//            MemoryUsageDemo, DemoDescription

public class SuperDemo extends ApplicationFrame
    implements ActionListener, TreeSelectionListener
{
    static class DisplayDemo
        implements Runnable
    {

        public void run()
        {
            try
            {
                Class class1 = Class.forName(demoDescription.getClassName());
                Method method = class1.getDeclaredMethod("createDemoPanel", null);
                JPanel jpanel = (JPanel)method.invoke(null, null);
                app.chartContainer.removeAll();
                app.chartContainer.add(jpanel);
                app.displayPanel.validate();
                String s = class1.getName();
                String s1 = s;
                int i = s.lastIndexOf('.');
                if(i > 0)
                    s1 = s.substring(i + 1);
                s1 = s1 + ".html";
                app.displayDescription(s1);
            }
            catch(ClassNotFoundException classnotfoundexception)
            {
                classnotfoundexception.printStackTrace();
            }
            catch(NoSuchMethodException nosuchmethodexception)
            {
                nosuchmethodexception.printStackTrace();
            }
            catch(InvocationTargetException invocationtargetexception)
            {
                invocationtargetexception.printStackTrace();
            }
            catch(IllegalAccessException illegalaccessexception)
            {
                illegalaccessexception.printStackTrace();
            }
        }

        private SuperDemo app;
        private DemoDescription demoDescription;

        public DisplayDemo(SuperDemo superdemo, DemoDescription demodescription)
        {
            app = superdemo;
            demoDescription = demodescription;
        }
    }


    public SuperDemo(String s)
    {
        super(s);
        setContentPane(createContent());
        setJMenuBar(createMenuBar());
    }

    private JComponent createContent()
    {
        JPanel jpanel = new JPanel(new BorderLayout());
        JTabbedPane jtabbedpane = new JTabbedPane();
        JPanel jpanel1 = new JPanel(new BorderLayout());
        jpanel1.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        JSplitPane jsplitpane = new JSplitPane(1);
        JTree jtree = new JTree(createTreeModel());
        jtree.addTreeSelectionListener(this);
        jsplitpane.setLeftComponent(new JScrollPane(jtree));
        jsplitpane.setRightComponent(createChartDisplayPanel());
        jpanel1.add(jsplitpane);
        jtabbedpane.add("Demos", jpanel1);
        MemoryUsageDemo memoryusagedemo = new MemoryUsageDemo(0x493e0);
        //(new MemoryUsageDemo.DataGenerator(memoryusagedemo, 1000)).start();
        (memoryusagedemo. new DataGenerator(100)).start();
        
        jtabbedpane.add("Memory Usage", memoryusagedemo);
        jtabbedpane.add("Source Code", createSourceCodePanel());
        jtabbedpane.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        jpanel.add(jtabbedpane);
        return jpanel;
    }

    private JMenuBar createMenuBar()
    {
        JMenuBar jmenubar = new JMenuBar();
        JMenu jmenu = new JMenu("File", true);
        jmenu.setMnemonic('F');
        JMenuItem jmenuitem = new JMenuItem("Exit", 120);
        jmenuitem.setActionCommand("EXIT");
        jmenuitem.addActionListener(this);
        jmenu.add(jmenuitem);
        jmenubar.add(jmenu);
        return jmenubar;
    }

    private JPanel createSourceCodePanel()
    {
        JPanel jpanel = new JPanel(new BorderLayout());
        jpanel.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        JEditorPane jeditorpane = new JEditorPane();
        jeditorpane.setEditable(false);
        java.net.URL url = (org.jfree.chart.demo.SuperDemo.class).getResource("source.html");
        if(url != null)
            try
            {
                jeditorpane.setPage(url);
            }
            catch(IOException ioexception)
            {
                System.err.println("Attempted to read a bad URL: " + url);
            }
        else
            System.err.println("Couldn't find file: source.html");
        JScrollPane jscrollpane = new JScrollPane(jeditorpane);
        jscrollpane.setVerticalScrollBarPolicy(20);
        jscrollpane.setPreferredSize(new Dimension(250, 145));
        jscrollpane.setMinimumSize(new Dimension(10, 10));
        jpanel.add(jscrollpane);
        return jpanel;
    }

    public void actionPerformed(ActionEvent actionevent)
    {
        String s = actionevent.getActionCommand();
        if(s.equals("EXIT"))
            attemptExit();
    }

    private void attemptExit()
    {
        String s = "Confirm";
        String s1 = "Are you sure you want to exit the demo?";
        int i = JOptionPane.showConfirmDialog(this, s1, s, 0, 3);
        if(i == 0)
        {
            dispose();
            System.exit(0);
        }
    }

    private JPanel createChartDisplayPanel()
    {
        displayPanel = new JPanel(new BorderLayout());
        chartContainer = new JPanel(new BorderLayout());
        chartContainer.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4), BorderFactory.createLineBorder(Color.black)));
        chartContainer.add(createNoDemoSelectedPanel());
        descriptionContainer = new JPanel(new BorderLayout());
        descriptionContainer.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        descriptionContainer.setPreferredSize(new Dimension(600, 140));
        descriptionPane = new JTextPane();
        descriptionPane.setEditable(false);
        JScrollPane jscrollpane = new JScrollPane(descriptionPane, 20, 31);
        descriptionContainer.add(jscrollpane);
        displayDescription("select.html");
        JSplitPane jsplitpane = new JSplitPane(0);
        jsplitpane.setTopComponent(chartContainer);
        jsplitpane.setBottomComponent(descriptionContainer);
        displayPanel.add(jsplitpane);
        jsplitpane.setDividerLocation(0.75D);
        return displayPanel;
    }

    private TreeModel createTreeModel()
    {
        DefaultMutableTreeNode defaultmutabletreenode = new DefaultMutableTreeNode("JFreeChart");
        defaultmutabletreenode.add(createPieChartsNode());
        defaultmutabletreenode.add(createBarChartsNode());
        defaultmutabletreenode.add(createLineChartsNode());
        defaultmutabletreenode.add(createAreaChartsNode());
        defaultmutabletreenode.add(createTimeSeriesChartsNode());
        defaultmutabletreenode.add(createFinancialChartsNode());
        defaultmutabletreenode.add(createXYChartsNode());
        defaultmutabletreenode.add(createMultipleAxisChartsNode());
        defaultmutabletreenode.add(createCombinedAxisChartsNode());
        defaultmutabletreenode.add(createGanttChartsNode());
        defaultmutabletreenode.add(createMiscellaneousChartsNode());
        return new DefaultTreeModel(defaultmutabletreenode);
    }

    private MutableTreeNode createPieChartsNode()
    {
        DefaultMutableTreeNode defaultmutabletreenode = new DefaultMutableTreeNode("Pie Charts");
        DefaultMutableTreeNode defaultmutabletreenode1 = new DefaultMutableTreeNode(new DemoDescription("demo.PieChartDemo1", "PieChartDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode2 = new DefaultMutableTreeNode(new DemoDescription("demo.PieChartDemo2", "PieChartDemo2.java"));
        DefaultMutableTreeNode defaultmutabletreenode3 = new DefaultMutableTreeNode(new DemoDescription("demo.PieChartDemo3", "PieChartDemo3.java"));
        DefaultMutableTreeNode defaultmutabletreenode4 = new DefaultMutableTreeNode(new DemoDescription("demo.PieChart3DDemo1", "PieChart3DDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode5 = new DefaultMutableTreeNode(new DemoDescription("demo.PieChart3DDemo2", "PieChart3DDemo2.java"));
        DefaultMutableTreeNode defaultmutabletreenode6 = new DefaultMutableTreeNode(new DemoDescription("demo.PieChart3DDemo3", "PieChart3DDemo3.java"));
        DefaultMutableTreeNode defaultmutabletreenode7 = new DefaultMutableTreeNode(new DemoDescription("demo.MultiplePieChartDemo1", "MultiplePieChartDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode8 = new DefaultMutableTreeNode(new DemoDescription("demo.RingChartDemo1", "RingChartDemo1.java"));
        defaultmutabletreenode.add(defaultmutabletreenode1);
        defaultmutabletreenode.add(defaultmutabletreenode2);
        defaultmutabletreenode.add(defaultmutabletreenode3);
        defaultmutabletreenode.add(defaultmutabletreenode4);
        defaultmutabletreenode.add(defaultmutabletreenode5);
        defaultmutabletreenode.add(defaultmutabletreenode6);
        defaultmutabletreenode.add(defaultmutabletreenode7);
        defaultmutabletreenode.add(defaultmutabletreenode8);
        return defaultmutabletreenode;
    }

    private MutableTreeNode createBarChartsNode()
    {
        DefaultMutableTreeNode defaultmutabletreenode = new DefaultMutableTreeNode("Bar Charts");
        defaultmutabletreenode.add(createCategoryBarChartsNode());
        defaultmutabletreenode.add(createXYBarChartsNode());
        return defaultmutabletreenode;
    }

    private MutableTreeNode createCategoryBarChartsNode()
    {
        DefaultMutableTreeNode defaultmutabletreenode = new DefaultMutableTreeNode("CategoryPlot");
        DefaultMutableTreeNode defaultmutabletreenode1 = new DefaultMutableTreeNode(new DemoDescription("demo.BarChartDemo1", "BarChartDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode2 = new DefaultMutableTreeNode(new DemoDescription("demo.BarChartDemo2", "BarChartDemo2.java"));
        DefaultMutableTreeNode defaultmutabletreenode3 = new DefaultMutableTreeNode(new DemoDescription("demo.BarChartDemo3", "BarChartDemo3.java"));
        DefaultMutableTreeNode defaultmutabletreenode4 = new DefaultMutableTreeNode(new DemoDescription("demo.BarChartDemo4", "BarChartDemo4.java"));
        DefaultMutableTreeNode defaultmutabletreenode5 = new DefaultMutableTreeNode(new DemoDescription("demo.BarChartDemo5", "BarChartDemo5.java"));
        DefaultMutableTreeNode defaultmutabletreenode6 = new DefaultMutableTreeNode(new DemoDescription("demo.BarChartDemo6", "BarChartDemo6.java"));
        DefaultMutableTreeNode defaultmutabletreenode7 = new DefaultMutableTreeNode(new DemoDescription("demo.BarChartDemo7", "BarChartDemo7.java"));
        DefaultMutableTreeNode defaultmutabletreenode8 = new DefaultMutableTreeNode(new DemoDescription("demo.BarChartDemo8", "BarChartDemo8.java"));
        DefaultMutableTreeNode defaultmutabletreenode9 = new DefaultMutableTreeNode(new DemoDescription("demo.BarChart3DDemo1", "BarChart3DDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode10 = new DefaultMutableTreeNode(new DemoDescription("demo.BarChart3DDemo2", "BarChart3DDemo2.java"));
        DefaultMutableTreeNode defaultmutabletreenode11 = new DefaultMutableTreeNode(new DemoDescription("demo.BarChart3DDemo3", "BarChart3DDemo3.java"));
        DefaultMutableTreeNode defaultmutabletreenode12 = new DefaultMutableTreeNode(new DemoDescription("demo.WaterfallChartDemo1", "WaterfallChartDemo1.java"));
        defaultmutabletreenode.add(defaultmutabletreenode1);
        defaultmutabletreenode.add(defaultmutabletreenode2);
        defaultmutabletreenode.add(defaultmutabletreenode3);
        defaultmutabletreenode.add(defaultmutabletreenode4);
        defaultmutabletreenode.add(defaultmutabletreenode5);
        defaultmutabletreenode.add(defaultmutabletreenode6);
        defaultmutabletreenode.add(defaultmutabletreenode7);
        defaultmutabletreenode.add(defaultmutabletreenode8);
        defaultmutabletreenode.add(defaultmutabletreenode9);
        defaultmutabletreenode.add(defaultmutabletreenode10);
        defaultmutabletreenode.add(defaultmutabletreenode11);
        defaultmutabletreenode.add(defaultmutabletreenode12);
        return defaultmutabletreenode;
    }

    private MutableTreeNode createXYBarChartsNode()
    {
        DefaultMutableTreeNode defaultmutabletreenode = new DefaultMutableTreeNode("XYPlot");
        DefaultMutableTreeNode defaultmutabletreenode1 = new DefaultMutableTreeNode(new DemoDescription("demo.XYBarChartDemo1", "XYBarChartDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode2 = new DefaultMutableTreeNode(new DemoDescription("demo.XYBarChartDemo2", "XYBarChartDemo2.java"));
        DefaultMutableTreeNode defaultmutabletreenode3 = new DefaultMutableTreeNode(new DemoDescription("demo.XYBarChartDemo3", "XYBarChartDemo3.java"));
        DefaultMutableTreeNode defaultmutabletreenode4 = new DefaultMutableTreeNode(new DemoDescription("demo.XYBarChartDemo4", "XYBarChartDemo4.java"));
        defaultmutabletreenode.add(defaultmutabletreenode1);
        defaultmutabletreenode.add(defaultmutabletreenode2);
        defaultmutabletreenode.add(defaultmutabletreenode3);
        defaultmutabletreenode.add(defaultmutabletreenode4);
        return defaultmutabletreenode;
    }

    private MutableTreeNode createLineChartsNode()
    {
        DefaultMutableTreeNode defaultmutabletreenode = new DefaultMutableTreeNode("Line Charts");
        DefaultMutableTreeNode defaultmutabletreenode1 = new DefaultMutableTreeNode(new DemoDescription("demo.AnnotationDemo1", "AnnotationDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode2 = new DefaultMutableTreeNode(new DemoDescription("demo.LineChartDemo1", "LineChartDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode3 = new DefaultMutableTreeNode(new DemoDescription("demo.LineChartDemo2", "LineChartDemo2.java"));
        DefaultMutableTreeNode defaultmutabletreenode4 = new DefaultMutableTreeNode(new DemoDescription("demo.LineChartDemo3", "LineChartDemo3.java"));
        DefaultMutableTreeNode defaultmutabletreenode5 = new DefaultMutableTreeNode(new DemoDescription("demo.LineChartDemo4", "LineChartDemo4.java"));
        DefaultMutableTreeNode defaultmutabletreenode6 = new DefaultMutableTreeNode(new DemoDescription("demo.LineChartDemo5", "LineChartDemo5.java"));
        DefaultMutableTreeNode defaultmutabletreenode7 = new DefaultMutableTreeNode(new DemoDescription("demo.LineChartDemo6", "LineChartDemo6.java"));
        defaultmutabletreenode.add(defaultmutabletreenode1);
        defaultmutabletreenode.add(defaultmutabletreenode2);
        defaultmutabletreenode.add(defaultmutabletreenode3);
        defaultmutabletreenode.add(defaultmutabletreenode4);
        defaultmutabletreenode.add(defaultmutabletreenode5);
        defaultmutabletreenode.add(defaultmutabletreenode6);
        defaultmutabletreenode.add(defaultmutabletreenode7);
        return defaultmutabletreenode;
    }

    private MutableTreeNode createAreaChartsNode()
    {
        DefaultMutableTreeNode defaultmutabletreenode = new DefaultMutableTreeNode("Area Charts");
        DefaultMutableTreeNode defaultmutabletreenode1 = new DefaultMutableTreeNode(new DemoDescription("demo.AreaChartDemo1", "AreaChartDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode2 = new DefaultMutableTreeNode(new DemoDescription("demo.XYAreaChartDemo1", "XYAreaChartDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode3 = new DefaultMutableTreeNode(new DemoDescription("demo.XYAreaChartDemo2", "XYAreaChartDemo2.java"));
        defaultmutabletreenode.add(defaultmutabletreenode1);
        defaultmutabletreenode.add(defaultmutabletreenode2);
        defaultmutabletreenode.add(defaultmutabletreenode3);
        return defaultmutabletreenode;
    }

    private MutableTreeNode createTimeSeriesChartsNode()
    {
        DefaultMutableTreeNode defaultmutabletreenode = new DefaultMutableTreeNode("Time Series Charts");
        DefaultMutableTreeNode defaultmutabletreenode1 = new DefaultMutableTreeNode(new DemoDescription("demo.TimeSeriesDemo1", "TimeSeriesDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode2 = new DefaultMutableTreeNode(new DemoDescription("demo.TimeSeriesDemo2", "TimeSeriesDemo2.java"));
        DefaultMutableTreeNode defaultmutabletreenode3 = new DefaultMutableTreeNode(new DemoDescription("demo.TimeSeriesDemo3", "TimeSeriesDemo3.java"));
        DefaultMutableTreeNode defaultmutabletreenode4 = new DefaultMutableTreeNode(new DemoDescription("demo.TimeSeriesDemo4", "TimeSeriesDemo4.java"));
        DefaultMutableTreeNode defaultmutabletreenode5 = new DefaultMutableTreeNode(new DemoDescription("demo.TimeSeriesDemo5", "TimeSeriesDemo5.java"));
        DefaultMutableTreeNode defaultmutabletreenode6 = new DefaultMutableTreeNode(new DemoDescription("demo.TimeSeriesDemo6", "TimeSeriesDemo6.java"));
        DefaultMutableTreeNode defaultmutabletreenode7 = new DefaultMutableTreeNode(new DemoDescription("demo.TimeSeriesDemo7", "TimeSeriesDemo7.java"));
        DefaultMutableTreeNode defaultmutabletreenode8 = new DefaultMutableTreeNode(new DemoDescription("demo.TimeSeriesDemo8", "TimeSeriesDemo8.java"));
        DefaultMutableTreeNode defaultmutabletreenode9 = new DefaultMutableTreeNode(new DemoDescription("demo.TimeSeriesDemo9", "TimeSeriesDemo9.java"));
        DefaultMutableTreeNode defaultmutabletreenode10 = new DefaultMutableTreeNode(new DemoDescription("demo.TimeSeriesDemo10", "TimeSeriesDemo10.java"));
        DefaultMutableTreeNode defaultmutabletreenode11 = new DefaultMutableTreeNode(new DemoDescription("demo.TimeSeriesDemo11", "TimeSeriesDemo11.java"));
        DefaultMutableTreeNode defaultmutabletreenode12 = new DefaultMutableTreeNode(new DemoDescription("demo.TimeSeriesDemo12", "TimeSeriesDemo12.java"));
        DefaultMutableTreeNode defaultmutabletreenode13 = new DefaultMutableTreeNode(new DemoDescription("demo.TimeSeriesDemo13", "TimeSeriesDemo13.java"));
        DefaultMutableTreeNode defaultmutabletreenode14 = new DefaultMutableTreeNode(new DemoDescription("demo.PeriodAxisDemo1", "PeriodAxisDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode15 = new DefaultMutableTreeNode(new DemoDescription("demo.PeriodAxisDemo2", "PeriodAxisDemo2.java"));
        DefaultMutableTreeNode defaultmutabletreenode16 = new DefaultMutableTreeNode(new DemoDescription("demo.DynamicDataDemo1", "DynamicDataDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode17 = new DefaultMutableTreeNode(new DemoDescription("demo.DynamicDataDemo2", "DynamicDataDemo2.java"));
        DefaultMutableTreeNode defaultmutabletreenode18 = new DefaultMutableTreeNode(new DemoDescription("demo.DynamicDataDemo3", "DynamicDataDemo3.java"));
        defaultmutabletreenode.add(defaultmutabletreenode1);
        defaultmutabletreenode.add(defaultmutabletreenode2);
        defaultmutabletreenode.add(defaultmutabletreenode3);
        defaultmutabletreenode.add(defaultmutabletreenode4);
        defaultmutabletreenode.add(defaultmutabletreenode5);
        defaultmutabletreenode.add(defaultmutabletreenode6);
        defaultmutabletreenode.add(defaultmutabletreenode7);
        defaultmutabletreenode.add(defaultmutabletreenode8);
        defaultmutabletreenode.add(defaultmutabletreenode9);
        defaultmutabletreenode.add(defaultmutabletreenode10);
        defaultmutabletreenode.add(defaultmutabletreenode11);
        defaultmutabletreenode.add(defaultmutabletreenode12);
        defaultmutabletreenode.add(defaultmutabletreenode13);
        defaultmutabletreenode.add(defaultmutabletreenode14);
        defaultmutabletreenode.add(defaultmutabletreenode15);
        defaultmutabletreenode.add(defaultmutabletreenode16);
        defaultmutabletreenode.add(defaultmutabletreenode17);
        defaultmutabletreenode.add(defaultmutabletreenode18);
        return defaultmutabletreenode;
    }

    private MutableTreeNode createFinancialChartsNode()
    {
        DefaultMutableTreeNode defaultmutabletreenode = new DefaultMutableTreeNode("Financial Charts");
        DefaultMutableTreeNode defaultmutabletreenode1 = new DefaultMutableTreeNode(new DemoDescription("demo.CandlestickChartDemo1", "CandlestickChartDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode2 = new DefaultMutableTreeNode(new DemoDescription("demo.HighLowChartDemo1", "HighLowChartDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode3 = new DefaultMutableTreeNode(new DemoDescription("demo.HighLowChartDemo2", "HighLowChartDemo2.java"));
        DefaultMutableTreeNode defaultmutabletreenode4 = new DefaultMutableTreeNode(new DemoDescription("demo.PriceVolumeDemo1", "PriceVolumeDemo1.java"));
        defaultmutabletreenode.add(defaultmutabletreenode1);
        defaultmutabletreenode.add(defaultmutabletreenode2);
        defaultmutabletreenode.add(defaultmutabletreenode3);
        defaultmutabletreenode.add(defaultmutabletreenode4);
        return defaultmutabletreenode;
    }

    private MutableTreeNode createXYChartsNode()
    {
        DefaultMutableTreeNode defaultmutabletreenode = new DefaultMutableTreeNode("XY Charts");
        DefaultMutableTreeNode defaultmutabletreenode1 = new DefaultMutableTreeNode(new DemoDescription("demo.XYLineAndShapeRendererDemo1", "XYLineAndShapeRendererDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode2 = new DefaultMutableTreeNode(new DemoDescription("demo.XYSeriesDemo1", "XYSeriesDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode3 = new DefaultMutableTreeNode(new DemoDescription("demo.XYSeriesDemo2", "XYSeriesDemo2.java"));
        DefaultMutableTreeNode defaultmutabletreenode4 = new DefaultMutableTreeNode(new DemoDescription("demo.XYSeriesDemo3", "XYSeriesDemo3.java"));
        DefaultMutableTreeNode defaultmutabletreenode5 = new DefaultMutableTreeNode(new DemoDescription("demo.WindChartDemo1", "WindChartDemo1.java"));
        defaultmutabletreenode.add(defaultmutabletreenode1);
        defaultmutabletreenode.add(defaultmutabletreenode2);
        defaultmutabletreenode.add(defaultmutabletreenode3);
        defaultmutabletreenode.add(defaultmutabletreenode4);
        defaultmutabletreenode.add(defaultmutabletreenode5);
        return defaultmutabletreenode;
    }

    private MutableTreeNode createMultipleAxisChartsNode()
    {
        DefaultMutableTreeNode defaultmutabletreenode = new DefaultMutableTreeNode("Multiple Axis Charts");
        DefaultMutableTreeNode defaultmutabletreenode1 = new DefaultMutableTreeNode(new DemoDescription("demo.DualAxisDemo1", "DualAxisDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode2 = new DefaultMutableTreeNode(new DemoDescription("demo.DualAxisDemo2", "DualAxisDemo2.java"));
        DefaultMutableTreeNode defaultmutabletreenode3 = new DefaultMutableTreeNode(new DemoDescription("demo.DualAxisDemo3", "DualAxisDemo3.java"));
        DefaultMutableTreeNode defaultmutabletreenode4 = new DefaultMutableTreeNode(new DemoDescription("demo.DualAxisDemo4", "DualAxisDemo4.java"));
        DefaultMutableTreeNode defaultmutabletreenode5 = new DefaultMutableTreeNode(new DemoDescription("demo.DualAxisDemo5", "DualAxisDemo5.java"));
        DefaultMutableTreeNode defaultmutabletreenode6 = new DefaultMutableTreeNode(new DemoDescription("demo.MultipleAxisDemo1", "MultipleAxisDemo1.java"));
        defaultmutabletreenode.add(defaultmutabletreenode1);
        defaultmutabletreenode.add(defaultmutabletreenode2);
        defaultmutabletreenode.add(defaultmutabletreenode3);
        defaultmutabletreenode.add(defaultmutabletreenode4);
        defaultmutabletreenode.add(defaultmutabletreenode5);
        defaultmutabletreenode.add(defaultmutabletreenode6);
        return defaultmutabletreenode;
    }

    private MutableTreeNode createCombinedAxisChartsNode()
    {
        DefaultMutableTreeNode defaultmutabletreenode = new DefaultMutableTreeNode("Combined Axis Charts");
        DefaultMutableTreeNode defaultmutabletreenode1 = new DefaultMutableTreeNode(new DemoDescription("demo.CombinedCategoryPlotDemo1", "CombinedCategoryPlotDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode2 = new DefaultMutableTreeNode(new DemoDescription("demo.CombinedCategoryPlotDemo2", "CombinedCategoryPlotDemo2.java"));
        DefaultMutableTreeNode defaultmutabletreenode3 = new DefaultMutableTreeNode(new DemoDescription("demo.CombinedTimeSeriesDemo1", "CombinedTimeSeriesDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode4 = new DefaultMutableTreeNode(new DemoDescription("demo.CombinedXYPlotDemo1", "CombinedXYPlotDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode5 = new DefaultMutableTreeNode(new DemoDescription("demo.CombinedXYPlotDemo2", "CombinedXYPlotDemo2.java"));
        DefaultMutableTreeNode defaultmutabletreenode6 = new DefaultMutableTreeNode(new DemoDescription("demo.CombinedXYPlotDemo3", "CombinedXYPlotDemo3.java"));
        DefaultMutableTreeNode defaultmutabletreenode7 = new DefaultMutableTreeNode(new DemoDescription("demo.CombinedXYPlotDemo4", "CombinedXYPlotDemo4.java"));
        defaultmutabletreenode.add(defaultmutabletreenode1);
        defaultmutabletreenode.add(defaultmutabletreenode2);
        defaultmutabletreenode.add(defaultmutabletreenode3);
        defaultmutabletreenode.add(defaultmutabletreenode4);
        defaultmutabletreenode.add(defaultmutabletreenode5);
        defaultmutabletreenode.add(defaultmutabletreenode6);
        defaultmutabletreenode.add(defaultmutabletreenode7);
        return defaultmutabletreenode;
    }

    private MutableTreeNode createGanttChartsNode()
    {
        DefaultMutableTreeNode defaultmutabletreenode = new DefaultMutableTreeNode("Gantt Charts");
        DefaultMutableTreeNode defaultmutabletreenode1 = new DefaultMutableTreeNode(new DemoDescription("demo.GanttDemo1", "GanttDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode2 = new DefaultMutableTreeNode(new DemoDescription("demo.GanttDemo2", "GanttDemo2.java"));
        defaultmutabletreenode.add(defaultmutabletreenode1);
        defaultmutabletreenode.add(defaultmutabletreenode2);
        return defaultmutabletreenode;
    }

    private MutableTreeNode createMiscellaneousChartsNode()
    {
        DefaultMutableTreeNode defaultmutabletreenode = new DefaultMutableTreeNode("Miscellaneous");
        DefaultMutableTreeNode defaultmutabletreenode1 = new DefaultMutableTreeNode(new DemoDescription("demo.BoxAndWhiskerChartDemo1", "BoxAndWhiskerChartDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode2 = new DefaultMutableTreeNode(new DemoDescription("demo.BubbleChartDemo1", "BubbleChartDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode3 = new DefaultMutableTreeNode(new DemoDescription("demo.CategoryStepChartDemo1", "CategoryStepChartDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode4 = new DefaultMutableTreeNode(new DemoDescription("demo.CompassDemo1", "CompassDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode5 = new DefaultMutableTreeNode(new DemoDescription("demo.CompassFormatDemo1", "CompassFormatDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode6 = new DefaultMutableTreeNode(new DemoDescription("demo.CompassFormatDemo2", "CompassFormatDemo2.java"));
        DefaultMutableTreeNode defaultmutabletreenode7 = new DefaultMutableTreeNode(new DemoDescription("demo.DifferenceChartDemo1", "DifferenceChartDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode8 = new DefaultMutableTreeNode(new DemoDescription("demo.DifferenceChartDemo2", "DifferenceChartDemo2.java"));
        DefaultMutableTreeNode defaultmutabletreenode9 = new DefaultMutableTreeNode(new DemoDescription("demo.EventFrequencyDemo1", "EventFrequencyDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode10 = new DefaultMutableTreeNode(new DemoDescription("demo.HideSeriesDemo1", "HideSeriesDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode11 = new DefaultMutableTreeNode(new DemoDescription("demo.OverlaidBarChartDemo1", "OverlaidBarChartDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode12 = new DefaultMutableTreeNode(new DemoDescription("demo.OverlaidBarChartDemo2", "OverlaidBarChartDemo2.java"));
        DefaultMutableTreeNode defaultmutabletreenode13 = new DefaultMutableTreeNode(new DemoDescription("demo.SpiderWebChartDemo1", "SpiderWebChartDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode14 = new DefaultMutableTreeNode(new DemoDescription("demo.PolarChartDemo1", "PolarChartDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode15 = new DefaultMutableTreeNode(new DemoDescription("demo.ThermometerDemo1", "ThermometerDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode16 = new DefaultMutableTreeNode(new DemoDescription("demo.YIntervalChartDemo1", "YIntervalChartDemo1.java"));
        defaultmutabletreenode.add(createCrosshairChartsNode());
        defaultmutabletreenode.add(createItemLabelsNode());
        defaultmutabletreenode.add(createMarkersNode());
        defaultmutabletreenode.add(createOrientationNode());
        defaultmutabletreenode.add(defaultmutabletreenode1);
        defaultmutabletreenode.add(defaultmutabletreenode2);
        defaultmutabletreenode.add(defaultmutabletreenode3);
        defaultmutabletreenode.add(defaultmutabletreenode4);
        defaultmutabletreenode.add(defaultmutabletreenode5);
        defaultmutabletreenode.add(defaultmutabletreenode6);
        defaultmutabletreenode.add(defaultmutabletreenode7);
        defaultmutabletreenode.add(defaultmutabletreenode8);
        defaultmutabletreenode.add(defaultmutabletreenode9);
        defaultmutabletreenode.add(defaultmutabletreenode10);
        defaultmutabletreenode.add(defaultmutabletreenode11);
        defaultmutabletreenode.add(defaultmutabletreenode12);
        defaultmutabletreenode.add(defaultmutabletreenode13);
        defaultmutabletreenode.add(defaultmutabletreenode14);
        defaultmutabletreenode.add(defaultmutabletreenode15);
        defaultmutabletreenode.add(defaultmutabletreenode16);
        return defaultmutabletreenode;
    }

    private MutableTreeNode createCrosshairChartsNode()
    {
        DefaultMutableTreeNode defaultmutabletreenode = new DefaultMutableTreeNode("Crosshairs");
        DefaultMutableTreeNode defaultmutabletreenode1 = new DefaultMutableTreeNode(new DemoDescription("demo.CrosshairDemo1", "CrosshairDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode2 = new DefaultMutableTreeNode(new DemoDescription("demo.CrosshairDemo2", "CrosshairDemo2.java"));
        DefaultMutableTreeNode defaultmutabletreenode3 = new DefaultMutableTreeNode(new DemoDescription("demo.CrosshairDemo3", "CrosshairDemo3.java"));
        DefaultMutableTreeNode defaultmutabletreenode4 = new DefaultMutableTreeNode(new DemoDescription("demo.CrosshairDemo4", "CrosshairDemo4.java"));
        defaultmutabletreenode.add(defaultmutabletreenode1);
        defaultmutabletreenode.add(defaultmutabletreenode2);
        defaultmutabletreenode.add(defaultmutabletreenode3);
        defaultmutabletreenode.add(defaultmutabletreenode4);
        return defaultmutabletreenode;
    }

    private MutableTreeNode createItemLabelsNode()
    {
        DefaultMutableTreeNode defaultmutabletreenode = new DefaultMutableTreeNode("Item Labels");
        DefaultMutableTreeNode defaultmutabletreenode1 = new DefaultMutableTreeNode(new DemoDescription("demo.ItemLabelDemo1", "ItemLabelDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode2 = new DefaultMutableTreeNode(new DemoDescription("demo.ItemLabelDemo2", "ItemLabelDemo2.java"));
        defaultmutabletreenode.add(defaultmutabletreenode1);
        defaultmutabletreenode.add(defaultmutabletreenode2);
        return defaultmutabletreenode;
    }

    private MutableTreeNode createMarkersNode()
    {
        DefaultMutableTreeNode defaultmutabletreenode = new DefaultMutableTreeNode("Markers");
        DefaultMutableTreeNode defaultmutabletreenode1 = new DefaultMutableTreeNode(new DemoDescription("demo.MarkerDemo1", "MarkerDemo1.java"));
        defaultmutabletreenode.add(defaultmutabletreenode1);
        return defaultmutabletreenode;
    }

    private MutableTreeNode createOrientationNode()
    {
        DefaultMutableTreeNode defaultmutabletreenode = new DefaultMutableTreeNode("Plot Orientation");
        DefaultMutableTreeNode defaultmutabletreenode1 = new DefaultMutableTreeNode(new DemoDescription("demo.PlotOrientationDemo1", "PlotOrientationDemo1.java"));
        DefaultMutableTreeNode defaultmutabletreenode2 = new DefaultMutableTreeNode(new DemoDescription("demo.PlotOrientationDemo2", "PlotOrientationDemo2.java"));
        defaultmutabletreenode.add(defaultmutabletreenode1);
        defaultmutabletreenode.add(defaultmutabletreenode2);
        return defaultmutabletreenode;
    }

    private void displayDescription(String s)
    {
        java.net.URL url = (org.jfree.chart.demo.SuperDemo.class).getResource(s);
        if(url != null)
            try
            {
                descriptionPane.setPage(url);
            }
            catch(IOException ioexception)
            {
                System.err.println("Attempted to read a bad URL: " + url);
            }
        else
            System.err.println("Couldn't find file: " + s);
    }

    public void valueChanged(TreeSelectionEvent treeselectionevent)
    {
        TreePath treepath = treeselectionevent.getPath();
        Object obj = treepath.getLastPathComponent();
        if(obj != null)
        {
            DefaultMutableTreeNode defaultmutabletreenode = (DefaultMutableTreeNode)obj;
            Object obj1 = defaultmutabletreenode.getUserObject();
            if(obj1 instanceof DemoDescription)
            {
                DemoDescription demodescription = (DemoDescription)obj1;
                SwingUtilities.invokeLater(new DisplayDemo(this, demodescription));
            } else
            {
                chartContainer.removeAll();
                chartContainer.add(createNoDemoSelectedPanel());
                displayPanel.validate();
                displayDescription("select.html");
            }
        }
        System.out.println(obj);
    }

    private JPanel createNoDemoSelectedPanel()
    {
        JPanel jpanel = new JPanel(new FlowLayout());
        jpanel.add(new JLabel("No demo selected"));
        jpanel.setPreferredSize(new Dimension(600, 400));
        return jpanel;
    }

    public static void main(String args[])
    {
        SuperDemo superdemo = new SuperDemo("JFreeChart Premium Demo Collection");
        superdemo.pack();
        RefineryUtilities.centerFrameOnScreen(superdemo);
        superdemo.setVisible(true);
    }

    public static final String EXIT_COMMAND = "EXIT";
    private JPanel displayPanel;
    private JPanel chartContainer;
    private JPanel descriptionContainer;
    private JTextPane descriptionPane;



}