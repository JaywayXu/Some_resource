// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 7/18/2005 5:13:46 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 

package org.jfree.chart.demo;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.data.general.DefaultPieDataset;

public class First
{

    public First()
    {
    }

    public static void main(String args[])
    {
        DefaultPieDataset defaultpiedataset = new DefaultPieDataset();
        defaultpiedataset.setValue("Category 1", 43.200000000000003D);
        defaultpiedataset.setValue("Category 2", 27.899999999999999D);
        defaultpiedataset.setValue("Category 3", 79.5D);
        org.jfree.chart.JFreeChart jfreechart = ChartFactory.createPieChart("Sample Pie Chart", defaultpiedataset, true, true, true);
        ChartFrame chartframe = new ChartFrame("First", jfreechart);
        chartframe.pack();
        chartframe.setVisible(true);
    }
}