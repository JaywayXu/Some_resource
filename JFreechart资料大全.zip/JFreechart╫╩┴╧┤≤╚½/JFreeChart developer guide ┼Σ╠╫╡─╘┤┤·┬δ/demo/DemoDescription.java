// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 7/18/2005 5:13:43 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 

package org.jfree.chart.demo;


public class DemoDescription
{

    public DemoDescription(String s, String s1)
    {
        className = s;
        description = s1;
    }

    public String getClassName()
    {
        return className;
    }

    public String getDescription()
    {
        return description;
    }

    public String toString()
    {
        return description;
    }

    private String className;
    private String description;
}