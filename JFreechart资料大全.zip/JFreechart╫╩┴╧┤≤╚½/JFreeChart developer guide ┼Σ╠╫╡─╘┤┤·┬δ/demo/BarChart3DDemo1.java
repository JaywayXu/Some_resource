// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 7/18/2005 5:13:38 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 

package org.jfree.chart.demo;

import java.awt.Dimension;
import javax.swing.JPanel;
import org.jfree.chart.*;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer3D;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class BarChart3DDemo1 extends ApplicationFrame
{

    public BarChart3DDemo1(String s)
    {
        super(s);
        CategoryDataset categorydataset = createDataset();
        JFreeChart jfreechart = createChart(categorydataset);
        ChartPanel chartpanel = new ChartPanel(jfreechart);
        chartpanel.setPreferredSize(new Dimension(500, 270));
        setContentPane(chartpanel);
    }

    private static CategoryDataset createDataset()
    {
        double ad[][] = {
            {
                10D, 4D, 15D, 14D
            }, {
                -5D, -7D, 14D, -3D
            }, {
                6D, 17D, -12D, 7D
            }, {
                7D, 15D, 11D, 0.0D
            }, {
                -8D, -6D, 10D, -9D
            }, {
                9D, 8D, 0.0D, 6D
            }, {
                -10D, 9D, 7D, 7D
            }, {
                11D, 13D, 9D, 9D
            }, {
                -3D, 7D, 11D, -10D
            }
        };
        return DatasetUtilities.createCategoryDataset("Series ", "Category ", ad);
    }

    private static JFreeChart createChart(CategoryDataset categorydataset)
    {
        JFreeChart jfreechart = ChartFactory.createBarChart3D("3D Bar Chart Demo", "Category", "Value", categorydataset, PlotOrientation.VERTICAL, true, true, false);
        CategoryPlot categoryplot = jfreechart.getCategoryPlot();
        categoryplot.setDomainGridlinesVisible(true);
        CategoryAxis categoryaxis = categoryplot.getDomainAxis();
        categoryaxis.setCategoryLabelPositions(CategoryLabelPositions.createUpRotationLabelPositions(0.39269908169872414D));
        BarRenderer3D barrenderer3d = (BarRenderer3D)categoryplot.getRenderer();
        barrenderer3d.setDrawBarOutline(false);
        return jfreechart;
    }

    public static JPanel createDemoPanel()
    {
        JFreeChart jfreechart = createChart(createDataset());
        return new ChartPanel(jfreechart);
    }

    public static void main(String args[])
    {
        BarChart3DDemo1 barchart3ddemo1 = new BarChart3DDemo1("3D Bar Chart Demo 1");
        barchart3ddemo1.pack();
        RefineryUtilities.centerFrameOnScreen(barchart3ddemo1);
        barchart3ddemo1.setVisible(true);
    }
}