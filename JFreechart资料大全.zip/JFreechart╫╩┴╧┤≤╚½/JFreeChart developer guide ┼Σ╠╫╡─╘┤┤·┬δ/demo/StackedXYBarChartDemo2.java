// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 7/18/2005 5:13:58 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 

package org.jfree.chart.demo;

import java.awt.Dimension;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.*;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StackedXYBarRenderer;
import org.jfree.data.time.Day;
import org.jfree.data.time.TimeTableXYDataset;
import org.jfree.data.xy.TableXYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class StackedXYBarChartDemo2 extends ApplicationFrame
{

    public StackedXYBarChartDemo2(String s)
    {
        super(s);
        TableXYDataset tablexydataset = createDataset();
        JFreeChart jfreechart = createChart(tablexydataset);
        ChartPanel chartpanel = new ChartPanel(jfreechart);
        chartpanel.setPreferredSize(new Dimension(500, 270));
        setContentPane(chartpanel);
    }

    private TableXYDataset createDataset()
    {
        TimeTableXYDataset timetablexydataset = new TimeTableXYDataset();
        Day day = new Day(1, 3, 2005);
        Day day1 = new Day(2, 3, 2005);
        Day day2 = new Day(3, 3, 2005);
        Day day3 = new Day(4, 3, 2005);
        Day day4 = new Day(5, 3, 2005);
        timetablexydataset.add(day, 1.0D, "Series 1");
        timetablexydataset.add(day1, 1.7D, "Series 1");
        timetablexydataset.add(day2, 2.2999999999999998D, "Series 1");
        timetablexydataset.add(day3, 3.7000000000000002D, "Series 1");
        timetablexydataset.add(day4, 2.6000000000000001D, "Series 1");
        timetablexydataset.add(day, 3.2000000000000002D, "Series 2");
        timetablexydataset.add(day1, 1.1000000000000001D, "Series 2");
        timetablexydataset.add(day2, 1.3999999999999999D, "Series 2");
        timetablexydataset.add(day3, 2.8999999999999999D, "Series 2");
        timetablexydataset.add(day4, 0.59999999999999998D, "Series 2");
        return timetablexydataset;
    }

    private JFreeChart createChart(TableXYDataset tablexydataset)
    {
        DateAxis dateaxis = new DateAxis("Date");
        dateaxis.setTickMarkPosition(DateTickMarkPosition.MIDDLE);
        NumberAxis numberaxis = new NumberAxis("Y");
        StackedXYBarRenderer stackedxybarrenderer = new StackedXYBarRenderer(0.10000000000000001D);
        stackedxybarrenderer.setDrawBarOutline(false);
        XYPlot xyplot = new XYPlot(tablexydataset, dateaxis, numberaxis, stackedxybarrenderer);
        JFreeChart jfreechart = new JFreeChart("Stacked XY Bar Chart Demo 2", xyplot);
        return jfreechart;
    }

    public static void main(String args[])
    {
        StackedXYBarChartDemo2 stackedxybarchartdemo2 = new StackedXYBarChartDemo2("Stacked XY Bar Chart Demo 2");
        stackedxybarchartdemo2.pack();
        RefineryUtilities.centerFrameOnScreen(stackedxybarchartdemo2);
        stackedxybarchartdemo2.setVisible(true);
    }
}